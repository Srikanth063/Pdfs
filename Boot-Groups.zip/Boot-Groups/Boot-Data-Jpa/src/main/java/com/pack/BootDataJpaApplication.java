package com.pack;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BootDataJpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(BootDataJpaApplication.class, args);
	}

}
