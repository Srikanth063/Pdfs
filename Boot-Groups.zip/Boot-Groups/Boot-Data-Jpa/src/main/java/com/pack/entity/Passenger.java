package com.pack.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;

@Entity
@NamedQuery(name="Passenger.findPassengers", 
            query="select  p  from  Passenger p  where  p.passengerId < 103 ")
public class Passenger {
	@Id
	private  Integer  passengerId;
	
	@Column(length=12)
	private  String  firstName;
	
	@Column(length=12)
	private  String  lastName;
	
	@Column(length=30)
	private  String  email;
	
	private  Long  contactNumber;
	
	private  Integer  seatNumber;
	
	public Passenger() {
		// TODO Auto-generated constructor stub
	}

	public Passenger(Integer passengerId, String firstName, String lastName, String email, Long contactNumber,
			Integer seatNumber) {
		super();
		this.passengerId = passengerId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.email = email;
		this.contactNumber = contactNumber;
		this.seatNumber = seatNumber;
	}

	public Integer getPassengerId() {
		return passengerId;
	}

	public void setPassengerId(Integer passengerId) {
		this.passengerId = passengerId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Long getContactNumber() {
		return contactNumber;
	}

	public void setContactNumber(Long contactNumber) {
		this.contactNumber = contactNumber;
	}

	public Integer getSeatNumber() {
		return seatNumber;
	}

	public void setSeatNumber(Integer seatNumber) {
		this.seatNumber = seatNumber;
	}

	@Override
	public String toString() {
		return "Passenger [passengerId=" + passengerId + ", firstName=" + firstName + ", lastName=" + lastName
				+ ", email=" + email + ", contactNumber=" + contactNumber + ", seatNumber=" + seatNumber + "]";
	}
	
	

}
