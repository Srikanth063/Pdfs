package com.pack.runner;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.pack.entity.Passenger;
import com.pack.repository.PassengerRepository;

@Component
public class MyRunner  implements CommandLineRunner {
	@Autowired
	PassengerRepository  repo;
	
	@Override
	public void run(String... args) throws Exception {
		/*
		Passenger  passenger1=new  Passenger(101, "Darren", "Joy", "darren.joy@gmail.com",9001002001L,15);
		
		Passenger  passenger2=new  Passenger(102, "Manoj", "Kumar", "manoj.k@gmail.com",7001002001L,18);
		
		Passenger  passenger3=new  Passenger(103, "Kiran", "Babu", "kiran.babu@gmail.com",6012453391L,23);
		
		repo.save(passenger1);
		repo.save(passenger2);
		repo.save(passenger3);
		*/
		
		/*
		Optional<Passenger>   opt = repo.findById(101);
		if(opt.isPresent()) {
			Passenger p=opt.get();
			System.out.println(p);
		}
		*/
		/*
		
		List<Passenger>   passList = repo.findAll();
		passList.forEach(p -> System.out.println(p));
		*/
		
		/*
		List<Passenger>  passengerList = repo.findByLastNameLike("%a%");
		passengerList.forEach(p -> System.out.println(p));
		*/
		
		List<Passenger>  passList = repo.findPassengers();
		passList.forEach(e -> System.out.println(e));
				
	}

}
