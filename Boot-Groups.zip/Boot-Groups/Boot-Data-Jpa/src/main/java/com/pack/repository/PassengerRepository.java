package com.pack.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.pack.entity.Passenger;

public interface PassengerRepository extends JpaRepository<Passenger, Integer> {
	
	List<Passenger>  findByLastNameLike(String str);
	
	List<Passenger>  findPassengers();

}
