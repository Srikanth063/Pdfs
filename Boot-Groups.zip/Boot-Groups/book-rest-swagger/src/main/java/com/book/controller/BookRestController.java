package com.book.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.book.dto.BookDTO;
import com.book.service.IBookService;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
public class BookRestController {
	
	@Autowired
	private IBookService  service;
	
	@GetMapping(value="/books")
	@ApiOperation("Fetches all the books from Database")
	public ResponseEntity<List<BookDTO>>  getBooks() {
		List<BookDTO>  bookDtoList=service.readAllBooks();
		return  new ResponseEntity<List<BookDTO>>(bookDtoList, HttpStatus.OK);
	}
	
	@GetMapping(value="/book/{bookId}", produces= {"application/json"})
	@ApiOperation("Fetches a book from Database with a given bookid")
	@ApiResponses({
		@ApiResponse(code=200, message="A book is fetched successfully"),
		@ApiResponse(code=404, message="Plese check the endpoint url once")
	})
	public  ResponseEntity<BookDTO>  getBookById(@PathVariable("bookId")Integer bookId){
		BookDTO  bookDto=service.readBookById(bookId);
		return  new  ResponseEntity<BookDTO>(bookDto,HttpStatus.OK);
	}
	
	/*
	@GetMapping(value="/book/{bookId}", produces= {"application/json"})
	@ApiOperation("Fetches a book from Database with a given bookid")
	public  ResponseEntity<BookDTO>  getBookByIdNew(@PathVariable("bookId")Integer bookId){
		BookDTO  bookDto=service.readBookByIdNew(bookId);
		return  new  ResponseEntity<BookDTO>(bookDto,HttpStatus.OK);
	}
	*/
	
	@GetMapping(value="/books/{title}")
	@ApiOperation("Fetches all the books from Database contains a given title")
	public  ResponseEntity<List<BookDTO>>  getBookByTitle(@PathVariable String title) {
		List<BookDTO>  bookDtoList=service.readBooksByTitle(title);
		return  new  ResponseEntity<List<BookDTO>>(bookDtoList,HttpStatus.OK);
	}
	
	@PostMapping(value="/book/create", consumes= {"application/json"})
	@ApiOperation("adds a new book to the Database")
	public  String  postBook(@RequestBody  BookDTO  bookDto) {
		return  service.addBook(bookDto);
	}
	
	@PutMapping(value="/book/update")
	@ApiOperation("updates a book in Database")
	public  String   modifyBook(@RequestBody  BookDTO bookDto) {
		return  service.updateBook(bookDto);
	}
	
	@DeleteMapping(value="/book/delete")
	@ApiOperation("deletes a book in Database")
	public  String  deleteBookById(@RequestParam("id") Integer bookId)  {
		return  service.deleteBook(bookId);
	}

}
