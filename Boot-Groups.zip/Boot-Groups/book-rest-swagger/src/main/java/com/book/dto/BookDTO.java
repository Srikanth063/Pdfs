package com.book.dto;

import javax.xml.bind.annotation.XmlRootElement;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@XmlRootElement(name="book")
@ApiModel(description="A BookDTO model")
public class BookDTO  implements  java.io.Serializable{
	
	@ApiModelProperty(notes="a bookid as integer")
	private  Integer  bookId;
	
	@ApiModelProperty(notes="a book tile")
	private  String   title;
	
	@ApiModelProperty(notes="a book price as a decimal value")
	private  Double   price;

	public Integer getBookId() {
		return bookId;
	}

	public void setBookId(Integer bookId) {
		this.bookId = bookId;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public Double getPrice() {
		return price;
	}

	public void setPrice(Double price) {
		this.price = price;
	}

}
