package com.otm.runner;

import java.util.Optional;
import java.util.Set;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.otm.entity.Customer;
import com.otm.entity.Order;
import com.otm.repository.CustomerRepository;
import com.otm.repository.OrderRepository;


@Component
public class MyRunner implements CommandLineRunner {
	
	@Autowired
	CustomerRepository  custRepo;
	
	@Autowired
	OrderRepository   orderRepo;
	
	
    @Transactional
	@Override
	public void run(String... args) throws Exception {
	
		
		//save a customer with associated collection
		/* 
		Customer  customer=new  Customer(102, "B", 8309071073L);
		
		Order    order1=new Order(231101, "LED TV", 40000.0);
		
		Order    order2=new Order(219021, "SHOE", 3000.0);
		
		//Order    order3=new Order(341109, "BAG", 500.0);
		
		Set<Order>   orders=new  HashSet<>();
		orders.add(order1);
		orders.add(order2);
		//orders.add(order3);
		
		customer.setOrders(orders);
		
		custRepo.save(customer);
		
		*/
		
		//load a customer with associated  collection
		/*
		
		Optional<Customer>  opt = custRepo.findById(101);
		Customer  customer = opt.get();
		Set<Order>   orders = customer.getOrders();
		
		orders.forEach(order -> System.out.println(order));
		
		*/
		
		//delete  a customer
		
		//custRepo.deleteById(101);
		
		//remove  an  order  from  associated collection of orders of a customer
		
		Optional<Customer>  opt = custRepo.findById(101);   
		Customer  customer = opt.get();
		Set<Order>  orders = customer.getOrders();
		
		Optional<Order>   opt2 = orderRepo.findById(191103);
		Order  order = opt2.get();
		
		orders.forEach( ord -> {
			if(ord.getOrderid().equals(order.getOrderid())) {
				System.out.println("DOne");
				orders.remove(ord);
			}
		});
			   	
		customer.setOrders(orders);
		
		//custRepo.saveAndFlush(customer);
		
		
		
	}

}
