package com.o2o.entity;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

@Entity
public class Passport {
	@GenericGenerator(name="g", strategy="foreign", parameters=@Parameter(name="property", value="person"))
	
	@Id
	@GeneratedValue(generator="g")
	private Integer  passportnumber;
	
	@Temporal(TemporalType.DATE)
	private  java.util.Date  expiredate;
	
	@OneToOne(cascade=CascadeType.ALL)
	@PrimaryKeyJoinColumn
	private  Person   person;

	public Integer getPassportnumber() {
		return passportnumber;
	}

	public void setPassportnumber(Integer passportnumber) {
		this.passportnumber = passportnumber;
	}

	public java.util.Date getExpiredate() {
		return expiredate;
	}

	public void setExpiredate(java.util.Date expiredate) {
		this.expiredate = expiredate;
	}

	public Person getPerson() {
		return person;
	}

	public void setPerson(Person person) {
		this.person = person;
	}

	@Override
	public String toString() {
		return "Passport [passportnumber=" + passportnumber + ", expiredate=" + expiredate + "]";
	}
	
	
		

}
