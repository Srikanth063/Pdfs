package com.o2o.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.o2o.entity.Passport;

public interface PassportRepository extends JpaRepository<Passport, Integer> {

}
