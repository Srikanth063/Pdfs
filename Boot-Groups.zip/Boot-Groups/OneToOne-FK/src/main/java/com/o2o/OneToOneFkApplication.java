package com.o2o;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OneToOneFkApplication {

	public static void main(String[] args) {
		SpringApplication.run(OneToOneFkApplication.class, args);
	}

}
