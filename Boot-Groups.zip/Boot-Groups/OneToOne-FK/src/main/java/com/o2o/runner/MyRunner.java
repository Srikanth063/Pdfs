package com.o2o.runner;

import java.text.SimpleDateFormat;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.o2o.entity.Passport;
import com.o2o.entity.Person;
import com.o2o.repository.PassportRepository;

@Component
public class MyRunner implements CommandLineRunner {
	
	@Autowired
	PassportRepository   passRepo;

	@Override
	public void run(String... args) throws Exception {
			
		Person  person=new  Person();
		person.setPersonid(11011);
		person.setPersonname("A");
		
		Passport  passport=new  Passport();
		//passport.setPassportnumber(20024);
		try {
			SimpleDateFormat  sdf=new  SimpleDateFormat("dd/MM/yyyy");
			java.util.Date   expiredate = sdf.parse("31/12/2029");
			passport.setExpiredate(expiredate);
		}catch(Exception  e) {
			System.out.println(e);
		}
		passport.setPerson(person);
		
		passRepo.save(passport);
		
		
	}

}
