package com.o2o.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.o2o.entity.Person;

public interface PersonRepository extends JpaRepository<Person, Integer> {

}
