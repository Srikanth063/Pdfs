package com.o2o;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OneToOneFkApplicationTests {

	@Test
	void contextLoads() {
	}

}
