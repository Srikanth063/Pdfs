package com.m2m.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.m2m.entity.Course;

public interface CourseRepository extends JpaRepository<Course, Integer> {

}
