package com.m2m.entity;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;

@Entity
public class Student {
	@Id
	private  Integer  studentId;
	
	@Column(length=20)
	private  String   studentName;
	
	@ManyToMany(cascade=CascadeType.ALL)	
	@JoinTable(name="STUDENT_COURSE",
	                    joinColumns=@JoinColumn(name="STUID_FK"),
	                    inverseJoinColumns=@JoinColumn(name="COURSEID_FK"))
	private  Set<Course>  courses;

	public Integer getStudentId() {
		return studentId;
	}

	public void setStudentId(Integer studentId) {
		this.studentId = studentId;
	}

	public String getStudentName() {
		return studentName;
	}

	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}

	public Set<Course> getCourses() {
		return courses;
	}

	public void setCourses(Set<Course> courses) {
		this.courses = courses;
	}

	@Override
	public String toString() {
		return "Student [studentId=" + studentId + ", studentName=" + studentName + "]";
	}
	
	
	

}
