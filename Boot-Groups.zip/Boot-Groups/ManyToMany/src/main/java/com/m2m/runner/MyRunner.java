package com.m2m.runner;

import java.util.HashSet;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.m2m.entity.Course;
import com.m2m.entity.Student;
import com.m2m.repository.CourseRepository;
import com.m2m.repository.StudentRepository;

@Component
public class MyRunner implements CommandLineRunner {
	
	@Autowired
	StudentRepository   studentRepo;
	
	@Autowired
	CourseRepository   courseRepo;
	

	@Override
	public void run(String... args) throws Exception {
		
		Student   s1 = new  Student();
		s1.setStudentId(1);   s1.setStudentName("A");
		
		Student   s2 =new  Student();
		s2.setStudentId(2);   s2.setStudentName("B");
		
		Course  c1=new Course();
		c1.setCourseId(901);  c1.setCourseName("JAVA");
		
		Course  c2=new  Course();
		c2.setCourseId(902);  c2.setCourseName("PYTHON");
		
		Course  c3=new  Course();
		c3.setCourseId(903);   c3.setCourseName(".NET");
		
		Set<Course>  courses1 = new  HashSet<>();
		courses1.add(c1);
		courses1.add(c2);
		s1.setCourses(courses1);
		
		Set<Course>  courses2 = new  HashSet<>();
		courses2.add(c1);
		courses2.add(c3);
		s2.setCourses(courses2);
		
		studentRepo.save(s1);
		studentRepo.save(s2);

	}

}
