package com.m2m.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.m2m.entity.Student;

public interface StudentRepository extends JpaRepository<Student, Integer> {

}
