package com.crm.model;

public enum Gender {
	MALE, FEMALE, OTHER
}
