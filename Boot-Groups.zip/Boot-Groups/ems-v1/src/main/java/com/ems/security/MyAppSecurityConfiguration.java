package com.ems.security;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

@Configuration
public class MyAppSecurityConfiguration extends WebSecurityConfigurerAdapter {
	
	@Autowired
	BCryptPasswordEncoder  encoder;
	
	@Bean
	public  BCryptPasswordEncoder  pwdEncoder( ) {
		return  new  BCryptPasswordEncoder();
	}
	
	@Override
	protected void configure(HttpSecurity http) throws Exception {
		http.authorizeRequests()
		/*
		 * The below configuration says that delete url of
		 * application can be accessed to a user with role
		 * MANAGER and other urls of application are accessible
		 * to any user.
		 */
		.antMatchers("/delete**").hasAnyRole("MANAGER")
		.anyRequest().permitAll()
		.and()
		/*
		 * httpBasic() configures HTTP Basic Authentication
		 * Spring security responds to browser with message
		 * authentication is required and browser will open
		 * a dialog box to accept user credentials.
		 */
	//	.httpBasic()
		
		/*
		 * formLogin() configures HTTP Form authentication
		 * Spring security provides a default login page to accept
		 * user credentials when a user makes a request to access 
		 * a protected resource.
		 */
		.formLogin()
		.and()
		/*
		 * For customized error page, instead default error page created
		 * by spring boot.
		 */
		.exceptionHandling().accessDeniedPage("/WEB-INF/views/accessDenied.jsp")

		.and()
		.csrf().disable();
	}
	
	@Autowired
    public  void  configureGloabl(AuthenticationManagerBuilder  builder) throws Exception {
		/*
		 * AuthenticationManagerBuilder is a helper class to build
		 * AuthenticationManager object.
		 * AuthenticationManager object stores user credentials with roles
		 * and spring security filters uses AuthenticationManager object
		 * in Authentication and Authorization process    	
		 */
		
		/*
		 * AuthenticationManager object can be built with in-memory user details
		 * or with user-details from a database.
		 */
		
		/*
		 * The below code builds AuthenticationManager object with in-memory
		 * user-details 
		 */
		
		builder.inMemoryAuthentication()
		.withUser("Payal").password(encoder.encode("pa@123")).roles("MANAGER")
		.and()
		.withUser("shekher").password(encoder.encode("123456")).roles("ADMIN");
    }

}
