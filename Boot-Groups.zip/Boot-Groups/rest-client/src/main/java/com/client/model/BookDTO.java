package com.client.model;

public class BookDTO  implements  java.io.Serializable{
	
	@Override
	public String toString() {
		return "BookDTO [bookId=" + bookId + ", title=" + title + ", price=" + price + "]";
	}

	private  Integer  bookId;
		
	private  String   title;
	
	private  Double   price;

	public Integer getBookId() {
		return bookId;
	}

	public void setBookId(Integer bookId) {
		this.bookId = bookId;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public Double getPrice() {
		return price;
	}

	public void setPrice(Double price) {
		this.price = price;
	}

}
