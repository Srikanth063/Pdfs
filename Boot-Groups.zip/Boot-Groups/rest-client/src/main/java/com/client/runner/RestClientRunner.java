package com.client.runner;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.client.model.BookDTO;

@Component
public class RestClientRunner implements CommandLineRunner {
	
	@Autowired
	RestTemplate  restTemplate;

	@Override
	public void run(String... args) throws Exception {
		/*
		 * invoke /books endpoint using HTTP GET
		 * call  exchange(param1,param2,param3,param4)
		 * param1: endpoint url
		 * param2: HttpMethod(enum)
		 * param3: HttpEntity object, for GET/DELETE url's it is null
		 * param4: ParameterizedTypeReference object, which enables capturing and passing a generic type
		 */
		ParameterizedTypeReference<List<BookDTO>> typeRef=new ParameterizedTypeReference<List<BookDTO>>() {};
		ResponseEntity<List<BookDTO>>  re = restTemplate.exchange("http://localhost:3232/BookApi/books", HttpMethod.GET, null, typeRef);
		List<BookDTO>  bookDtoList=re.getBody();
		bookDtoList.forEach(dto->System.out.println(dto));
		
		/*
		 * invoke  /book/{bookid}  endpoint using Http GET
		 * call getForObject(param1,param2)
		 * param1: endpoint url
		 * param2: Class object of response type
		 */
		System.out.println("=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=");
		
		BookDTO  dto = restTemplate.getForObject("http://localhost:3232/BookApi/book/105", BookDTO.class);
		System.out.println(dto);
		
		System.out.println("-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=");
		
		/*
		 * invoke  /book/create endpoint using HTTP POST
		 * call exchange(p1,p2,p3,p4)
		 */
		BookDTO  bookDto=new  BookDTO();
		bookDto.setBookId(107);
		bookDto.setTitle("Learn Angular");
		bookDto.setPrice(500.0);
		
		HttpEntity<BookDTO>  httpEntity=new HttpEntity<BookDTO>(bookDto);
		ResponseEntity<String>  re2=restTemplate.exchange("http://localhost:3232/BookApi/book/create", HttpMethod.POST, httpEntity, String.class);
		System.out.println(re2.getBody());
		System.out.println("-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=");
		
		/*
		 * invoke  /book/delete  endpoint using HTTP DELETE
		 * call  exchange(p1, p2, p3, p4)
		 */
		ResponseEntity<String> re3= restTemplate.exchange("http://localhost:3232/BookApi/book/delete?id=103", HttpMethod.DELETE, null, String.class);
		System.out.println(re3.getBody());
		System.out.println("-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=");
		
		/*
		 * invoke  books/{title}  endpoint  using  HTTP GET
		 */
		
		ParameterizedTypeReference<List<BookDTO>> typeRef2=new ParameterizedTypeReference<List<BookDTO>>() {};
		ResponseEntity<List<BookDTO>>  re4 = restTemplate.exchange("http://localhost:3232/BookApi/books/{title}", HttpMethod.GET, null, typeRef2, "%Learn%");
		List<BookDTO>  bookDtoList2=re4.getBody();
		bookDtoList2.forEach(dto2->System.out.println(dto2));
		
		

	}

}
