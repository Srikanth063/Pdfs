package com.m2o;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.m2o.entity.Order;
import com.m2o.repository.OrderRepository;

@SpringBootApplication
public class ManyToOneApplication  implements  CommandLineRunner {
	
	@Autowired
	OrderRepository   orderRepo;

	public static void main(String[] args) {
		SpringApplication.run(ManyToOneApplication.class, args);
	}
	
	@Override
	public void run(String... args) throws Exception {
		
		/*
		
		Customer  customer=new  Customer(101, "A", 8309071073L);
		
		Order    order1=new Order(231101, "LED TV", 40000.0);
		
		Order    order2=new Order(219021, "SHOE", 3000.0);
		
		Order    order3=new Order(341109, "BAG", 500.0);
		
		order1.setCustomer(customer);
		order2.setCustomer(customer);
		order3.setCustomer(customer);
		
		//orderRepo.save(order1);
		//orderRepo.save(order2);
		//orderRepo.save(order3);
		
		*/
		
		orderRepo.deleteById(231101);
		
	}

}
