package com.m2o.entity;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="ORDERS")
public class Order {
	@Id
	private  Integer  orderid;
	
	@Column(length=20)
	private  String  itemname;
	
	private  Double  price;
	
	@ManyToOne(cascade=CascadeType.PERSIST)
	@JoinColumn(name="CUSTID_FK")
	private   Customer   customer;
	
	public Order() {
		// TODO Auto-generated constructor stub
	}

	public Order(Integer orderid, String itemname, Double price) {
		super();
		this.orderid = orderid;
		this.itemname = itemname;
		this.price = price;
	}

	public Integer getOrderid() {
		return orderid;
	}

	public void setOrderid(Integer orderid) {
		this.orderid = orderid;
	}

	public String getItemname() {
		return itemname;
	}

	public void setItemname(String itemname) {
		this.itemname = itemname;
	}

	public Double getPrice() {
		return price;
	}

	public void setPrice(Double price) {
		this.price = price;
	}
	
	
	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	@Override
	public String toString() {
		return "Order [orderid=" + orderid + ", itemname=" + itemname + ", price=" + price + "]";
	}
	
	

}
