package com.book.exception;

public class BookDoesNotExistException extends RuntimeException {

}
