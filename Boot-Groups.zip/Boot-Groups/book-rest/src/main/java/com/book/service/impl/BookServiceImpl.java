package com.book.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.book.dto.BookDTO;
import com.book.entity.Book;
import com.book.repository.BookRepository;
import com.book.service.IBookService;

@Service
public class BookServiceImpl implements IBookService {
	
	@Autowired
	BookRepository  repository;

	@Override
	public List<BookDTO> readAllBooks() {
		List<Book>  bookList = repository.findAll();
		List<BookDTO> bookDtoList = new  ArrayList<BookDTO>();
		
		bookList.forEach(book -> {
			BookDTO  bookDto=new  BookDTO();
			BeanUtils.copyProperties(book, bookDto);
			bookDtoList.add(bookDto);
		});
		return  bookDtoList;
	}

	@Override
	public BookDTO readBookById(Integer bookId) {
		Book  book = repository.findById(bookId).get();
		BookDTO  bookDto =new  BookDTO();
		BeanUtils.copyProperties(book, bookDto);
		return  bookDto;
	}

	@Override
	public List<BookDTO> readBooksByTitle(String pattern) {
		List<Book>  bookList = repository.findBooksByTitle(pattern);
		List<BookDTO> bookDtoList = new  ArrayList<BookDTO>();
		
		bookList.forEach(book -> {
			BookDTO  bookDto=new  BookDTO();
			BeanUtils.copyProperties(book, bookDto);
			bookDtoList.add(bookDto);
		});
		return  bookDtoList;
	}

	@Override
	public String addBook(BookDTO dto) {
		boolean flag=repository.existsById(dto.getBookId());
		if(flag==true) {
			return  "Sorry, a book with the given bookid already exist";
		}
		else {
			Book  book=new Book();
			BeanUtils.copyProperties(dto, book);
			repository.save(book);
			return "book is added to the database";
		}
	}

	@Override
	public String updateBook(BookDTO dto) {
		boolean flag=repository.existsById(dto.getBookId());
		if(flag==true) {
			Book  book=new Book();
			BeanUtils.copyProperties(dto, book);
			repository.saveAndFlush(book);
			return "book is updated to the database";
		}
		else {
			return "sorry, book doesn't exist with given id";
		}
	}

	@Override
	public String deleteBook(Integer bookId) {
		boolean flag=repository.existsById(bookId);
		if(flag==true) {
			repository.deleteById(bookId);
			return "Book is deleted from Database";
		}
		else {
			return "Sorry, book doesn't exist with given id";
		}
	}

}
