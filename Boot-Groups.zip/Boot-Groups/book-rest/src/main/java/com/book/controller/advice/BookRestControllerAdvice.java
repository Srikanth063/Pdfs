package com.book.controller.advice;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.book.exception.BookDoesNotExistException;
import com.book.exception.ErrorMessage;

@RestControllerAdvice
public class BookRestControllerAdvice {
	
	@ExceptionHandler(BookDoesNotExistException.class)
	public  ResponseEntity<ErrorMessage>  exHandler1(BookDoesNotExistException  e) {
		ErrorMessage  em =new  ErrorMessage();
		em.setMessage("A Book with given id doesn't exist in Database");
		return  new  ResponseEntity<ErrorMessage>(em, HttpStatus.BAD_REQUEST);
	}

}
