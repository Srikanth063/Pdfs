package com.book.service;

import java.util.List;

import com.book.dto.BookDTO;

public interface IBookService {
	List<BookDTO>  readAllBooks();
	BookDTO  readBookById(Integer  bookId);
	List<BookDTO>  readBooksByTitle(String pattern);
	String  addBook(BookDTO  dto);
	String  updateBook(BookDTO  dto);
	String  deleteBook(Integer  bookId);

}
